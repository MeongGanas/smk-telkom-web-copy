<template lang="">
  <q-layout>
    <div
      class="q-px-xl"
      style="
        background: #bd2130;
        height: 100vh;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
      "
    >
      <div class="text-white q-py-xl" style="width: 50%">
        <h1 class="text-h4" style="font-weight: 600">Assalamualaikum Wr. Wb</h1>
        <p class="text-subtitle2">
          Puji Syukur Alhamdulillah kita panjatkan ke hadirat Allah SWT, atas
          segala rahmat dan hidayah-Nya sehingga kita masih diberi kesempatan
          untuk bekerja dan berkarya di bidang pendidikan. Karena pendidikan
          merupakan upaya kita untuk menyiapkan generasi penerus bangsa, yang
          akan menggantikan estafet kepemimpinan kita di masa mendatang.
        </p>
        <p class="text-subtitle2">
          Kami mengucapkan selamat datang di website resmi SMK Telkom Makassar
          yang dapat digunakan sebagai salah satu media komunikasi, dan
          interaksi antara civitas akademika dan masyarakat pada umumnya.
        </p>
        <p class="text-subtitle2">
          Mari kita bekerja dan berkarya dengan mengharap ridho-Nya dan
          keikhlasan yang tulus demi menyiapkan generasi bangsa yang
          berintegritas dan berprestasi.
        </p>
        <p class="text-subtitle2">Wassalamualaikum Wr. Wb</p>
        <p class="text-subtitle2">Drs. Abd. Halim Samad, MM</p>
      </div>
      <div class="q-ml-xl">
        <div style="background: rgba(255, 255, 255, 0.1); height: 100%">
          <img src="img/fotobapak4_xuztb6.png" alt="" style="width: 500px" />
        </div>
      </div>
    </div>
  </q-layout>
</template>
<script>
export default {};
</script>
<style scoped></style>
